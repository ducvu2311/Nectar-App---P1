import React, { useState } from "react";
import { View, TextInput, TouchableOpacity, Text, StyleSheet } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";

const SelectLocationScreen = ({ navigation }) => {
  const [location, setLocation] = useState("");

  const handleContinue = () => {
    // Kiểm tra dữ liệu nếu cần, sau đó chuyển màn hình
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Enter Your Location</Text>
      <View style={styles.inputContainer}>
        <Ionicons name="location-outline" size={24} color="#6BBE66" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Type your location"
          value={location}
          onChangeText={setLocation}
          placeholderTextColor="#888"
        />
      </View>
      <TouchableOpacity
        style={[styles.button, !location && styles.buttonDisabled]}
        onPress={handleContinue}
        disabled={!location}
      >
        <Text style={styles.buttonText}>Continue</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
    justifyContent: "center"
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginBottom: 20
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10
  },
  icon: {
    marginRight: 10
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#333"
  },
  button: {
    backgroundColor: "#6BBE66",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20
  },
  buttonDisabled: {
    backgroundColor: "#ccc"
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold"
  }
});

export default SelectLocationScreen;
