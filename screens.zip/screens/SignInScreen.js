import React, { useState } from "react";
import { 
  View, 
  Text, 
  Image, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity 
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";

const CombinedSignInScreen = ({ navigation }) => {
  // Quản lý bước hiện tại (0: số điện thoại, 1: OTP, 2: vị trí)
  const [step, setStep] = useState(0);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [location, setLocation] = useState("");

  // Xử lý khi nhập số điện thoại xong
  const handlePhoneSubmit = () => {
    // Gửi OTP từ backend nếu cần...
    setStep(1);
  };

  // Xử lý khi nhập OTP
  const handleOtpSubmit = () => {
    // Xác nhận OTP từ backend...
    setStep(2);
  };

  // Xử lý khi nhập vị trí
  const handleLocationSubmit = () => {
    // Lưu thông tin vị trí nếu cần...
    // Sau đó chuyển sang màn hình Login
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      {/* Bước 0: Nhập số điện thoại & Social */}
      {step === 0 && (
        <View style={styles.stepContainer}>
          {/* Hình ảnh ở đầu màn hình */}
          <Image 
            source={require("../assets/groceries.jpg")} 
            style={styles.topImage} 
          />
          <Text style={styles.title}>Get your groceries with nectar</Text>
          
          {/* Nhập số điện thoại với cờ Bangladesh */}
          <View style={styles.phoneContainer}>
            <View style={styles.countryCodeContainer}>
              <Image 
                source={require("../assets/bd_flag.jpg")} 
                style={styles.flagImage} 
              />
              <Text style={styles.countryCodeText}>+084</Text>
            </View>
            <TextInput
              style={styles.phoneInput}
              placeholder="Mobile Number"
              keyboardType="phone-pad"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              placeholderTextColor="#999"
            />
          </View>

          {/* Hoặc kết nối qua mạng xã hội */}
          <Text style={styles.orText}>Or connect with social media</Text>

          {/* Nút Google */}
          <TouchableOpacity style={styles.googleButton}>
            <Text style={styles.googleButtonText}>Continue with Google</Text>
          </TouchableOpacity>

          {/* Nút Facebook */}
          <TouchableOpacity style={styles.facebookButton}>
            <Text style={styles.facebookButtonText}>Continue with Facebook</Text>
          </TouchableOpacity>

          {/* Nút tiếp tục -> sang bước OTP */}
          <TouchableOpacity 
            style={[styles.continueButton, !phoneNumber && styles.buttonDisabled]} 
            onPress={handlePhoneSubmit} 
            disabled={!phoneNumber}
          >
            <Text style={styles.continueButtonText}>Next</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Bước 1: Nhập OTP */}
      {step === 1 && (
        <View style={styles.stepContainer}>
          <Text style={styles.title}>Enter OTP</Text>
          <TextInput
            style={styles.input}
            placeholder="OTP Code"
            keyboardType="number-pad"
            value={otp}
            onChangeText={setOtp}
            placeholderTextColor="#999"
          />
          <TouchableOpacity 
            style={[styles.continueButton, !otp && styles.buttonDisabled]} 
            onPress={handleOtpSubmit}
            disabled={!otp}
          >
            <Text style={styles.continueButtonText}>Verify OTP</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Bước 2: Nhập vị trí */}
      {step === 2 && (
        <View style={styles.stepContainer}>
          <Text style={styles.title}>Enter Your Location</Text>
          <View style={styles.locationContainer}>
            <Ionicons name="location-outline" size={24} color="#6BBE66" style={styles.locationIcon} />
            <TextInput
              style={styles.locationInput}
              placeholder="Type your location"
              value={location}
              onChangeText={setLocation}
              placeholderTextColor="#999"
            />
          </View>
          <TouchableOpacity 
            style={[styles.continueButton, !location && styles.buttonDisabled]} 
            onPress={handleLocationSubmit}
            disabled={!location}
          >
            <Text style={styles.continueButtonText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

export default CombinedSignInScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 20,
    paddingTop: 50,
  },
  stepContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  topImage: {
    width: "100%",
    height: 200,
    resizeMode: "contain",
    marginBottom: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginBottom: 20,
  },
  phoneContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    overflow: "hidden",
    marginBottom: 20,
  },
  countryCodeContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    backgroundColor: "#f5f5f5",
  },
  flagImage: {
    width: 25,
    height: 15,
    resizeMode: "cover",
    marginRight: 5,
  },
  countryCodeText: {
    fontSize: 16,
    color: "#333",
    marginRight: 10,
  },
  phoneInput: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 10,
    fontSize: 16,
    color: "#333",
  },
  orText: {
    textAlign: "center",
    color: "#999",
    marginVertical: 20,
  },
  googleButton: {
    backgroundColor: "#4285F4",
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 15,
    width: "100%",
  },
  googleButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  facebookButton: {
    backgroundColor: "#3B5998",
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 20,
    width: "100%",
  },
  facebookButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  continueButton: {
    backgroundColor: "#6BBE66",
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: "center",
    width: "100%",
  },
  continueButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  buttonDisabled: {
    backgroundColor: "#ccc",
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    fontSize: 16,
    color: "#333",
    marginBottom: 20,
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 20,
  },
  locationIcon: {
    marginRight: 10,
  },
  locationInput: {
    flex: 1,
    fontSize: 16,
    color: "#333",
  },
});
