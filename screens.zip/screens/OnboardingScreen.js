import React from "react";
import { View, ImageBackground, StyleSheet, TouchableOpacity, Text } from "react-native";

const OnboardingScreen = ({ navigation }) => {
  return (
    <ImageBackground source={require("../assets/onboarding.jpg")} style={styles.background}>
      <TouchableOpacity style={styles.getStartedButton} onPress={() => navigation.navigate("SignIn")}>
        <Text style={styles.getStartedText}>Get Started</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "flex-end"
  },
  getStartedButton: {
    backgroundColor: "#6BBE66",
    margin: 20,
    paddingVertical: 15,
    borderRadius: 30,
    alignItems: "center"
  },
  getStartedText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold"
  }
});

export default OnboardingScreen;
