import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";

const OTPVerificationScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>OTP Verification</Text>
      <Text style={styles.subHeader}>Enter the OTP sent to your mobile number</Text>
      <TextInput 
        style={styles.input} 
        placeholder="OTP Code" 
        keyboardType="number-pad" 
        placeholderTextColor="#888" 
      />
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("SelectLocation")}>
        <Text style={styles.buttonText}>Verify</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#333"
  },
  subHeader: {
    fontSize: 16,
    color: "#666",
    textAlign: "center",
    marginBottom: 20
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    marginBottom: 20
  },
  button: {
    backgroundColor: "#6BBE66",
    padding: 15,
    borderRadius: 10,
    width: "100%",
    alignItems: "center"
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold"
  }
});

export default OTPVerificationScreen;
