import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";

const MobileNumberScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Enter Mobile Number</Text>
      <TextInput 
        style={styles.input} 
        placeholder="Mobile Number" 
        keyboardType="phone-pad" 
        placeholderTextColor="#888" 
      />
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("OTPVerification")}>
        <Text style={styles.buttonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
    alignItems: "center",
    justifyContent: "center"
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#333"
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    marginBottom: 20
  },
  button: {
    backgroundColor: "#6BBE66",
    padding: 15,
    borderRadius: 10,
    width: "100%",
    alignItems: "center"
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold"
  }
});

export default MobileNumberScreen;
